package tests

import org.scalatest._
import game.enemyai._
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.maps.GridLocation

class Task1 extends FunSuite {

  var epsilon: Double= .001
  def compareDoubles(d1: Double, d2: Double): Boolean ={
    Math.abs(d1-d2)<epsilon
  }

  test("your test") {

    var AIp1= new AIPlayer("1")

    var AIps: LinkedListNode[PlayerLocation] = new LinkedListNode[PlayerLocation](new PlayerLocation(0,0,"1"),null)
    AIps=new LinkedListNode[PlayerLocation](new PlayerLocation(2,4,"2"),AIps)
    AIps=new LinkedListNode[PlayerLocation](new PlayerLocation(6,6,"3"),AIps)



    assert(compareDoubles(AIp1.locatePlayer("2", AIps).x , 2))
    assert(compareDoubles(AIp1.locatePlayer("2", AIps).y , 4))
    assert(AIp1.locatePlayer("2", AIps).playerId == "2")

    //=====

    assert(AIp1.closestPlayer(AIps).playerId == "2")

    //=====

    val path1 = AIp1.computePath(new GridLocation(1,3), new GridLocation(2,2))//SE short

    assert(path1.value.x == 1 && path1.value.y == 3)

    //assert(path1.next.value.x == 1 && path1.next.value.y == 2)
    assert(path1.next.value.x == 2 && path1.next.value.y == 3)


    assert(path1.next.next.value.x == 2 && path1.next.next.value.y == 2)



    //val path3 = AIp1.computePath(new GridLocation(1,4), new GridLocation(3,1)) SE long

    //val path4 = AIp1.computePath(new GridLocation(2,3), new GridLocation(1,2)) SW short

    //val path5 = AIp1.computePath(new GridLocation(3,4), new GridLocation(1,1)) SW long

    //val path6 = AIp1.computePath(new GridLocation(5,2), new GridLocation(5,3)) N short and long

    //val path7 = AIp1.computePath(new GridLocation(5,7), new GridLocation(5,2)) S short and long

    //val path8 = AIp1.computePath(new GridLocation(4,4), new GridLocation(2,4)) W short and long

    //val path9 = AIp1.computePath(new GridLocation(2,4), new GridLocation(6,4)) E short and long

    //val path10 = AIp1.computePath(new GridLocation(2,1), new GridLocation(1,2)) NW short and long

    //val path11 = AIp1.computePath(new GridLocation(1,2), new GridLocation(3,5))



    println("s")

/* fails autolab
    val path2 = AIp1.computePath(new GridLocation(2,2), new GridLocation(1,3))

    assert(path2.value.x == 2 && path2.value.y == 2)

    assert(path2.next.value.x == 2 && path2.next.value.y == 3)

    assert(path2.next.next.value.x == 1 && path2.next.next.value.y == 3)



 */

  }

}
