package game.enemyai

import game.enemyai.decisiontree.DecisionTreeValue
import game.lo4_data_structures.linkedlist.LinkedListNode
import game.lo4_data_structures.trees.BinaryTreeNode
import game.maps.GridLocation
import game.{AIAction, MovePlayer}

class AIPlayer(val id: String) {

  def locatePlayer(playerId: String, playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {
    if (playerLocations.value.playerId == playerId) {
      playerLocations.value
    } else {
      locatePlayer(playerId, playerLocations.next)
    }
  }


  def closestPlayer(playerLocations: LinkedListNode[PlayerLocation]): PlayerLocation = {

    var distance = d(this.locatePlayer(id, playerLocations).x, this.locatePlayer(id, playerLocations).y, playerLocations.value.x, playerLocations.value.y)
    var pLocations = playerLocations
    var ans: PlayerLocation = pLocations.value

    while (pLocations != null) {
      var newDistance = d(this.locatePlayer(id, playerLocations).x, this.locatePlayer(id, playerLocations).y, pLocations.value.x, pLocations.value.y)
      if (distance > newDistance && newDistance != 0 && distance != 0) {

        ans = pLocations.value
        distance = newDistance

      }
      pLocations = pLocations.next
    }
    ans

  }

  def d(x1: Double, y1: Double, x2: Double, y2: Double): Double = {
    Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))
  }


  // TODO: Replace this placeholder code with your own
  def computePath(start: GridLocation, end: GridLocation): LinkedListNode[GridLocation] = {

    var path: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](start, null)
    var path2: LinkedListNode[GridLocation] = new LinkedListNode[GridLocation](new GridLocation(end.x,start.y), null)

    var startX = start.x
    var startY = start.y

    var endX = end.x
    var endY = end.y

    var xTravel = end.x - start.x
    var yTravel = end.y - start.y

    if(xTravel == 0 && yTravel < 0){
      for (y <- startY-1 to end.y by -1) {
        path.next = new LinkedListNode[GridLocation](new GridLocation(endX, endY), path.next)
        endY +=1
      }
    }else if(xTravel == 0 && yTravel > 0){
      for (y <- end.y to startY+1 by -1) {
        path.next = new LinkedListNode[GridLocation](new GridLocation(endX, y), path.next)
      }
    }

    else if(xTravel < 0 && yTravel == 0){
      for (x <- endX to startX-1) {
        path.next = new LinkedListNode[GridLocation](new GridLocation(x, endY), path.next)
      }
    }else if(xTravel > 0 && yTravel == 0){
      for (x <- endX to startX+1 by -1) {
        path.next = new LinkedListNode[GridLocation](new GridLocation(x, endY), path.next)
      }
    }
    else if(yTravel > 0) {

        for (y <- startY to endY) {
          if(xTravel > 0){
            for (x <- endX-1 to startX+1 by -1) {
              //println("test")
              if(x == startX+1){
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path2)
              }else{
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path.next)
              }
            }

            if(xTravel == 1){
              path.next = path2
            }

            xTravel = 0
          }else if(xTravel < 0){

            for (x <- endX+1 to startX-1) {
              if(x == startX-1){
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path2)
              }else{
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path.next)
              }
            }

            if(xTravel == -1){
              path.next = path2
            }

            xTravel = 0

          } else{
            path2.next = new LinkedListNode[GridLocation](new GridLocation(endX, endY), path2.next)
            endY-=1
          }
        }

    }else if(yTravel < 0){

        for (y <- startY to end.y by -1) {

          if(xTravel > 0) { //this works

            for (x <- endX-1 to startX+1 by -1) {
              //println("test")
              if(x == startX+1){
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path2)
              }else{
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path.next)
              }
            }

            if(xTravel == 1){
              path.next = path2
            }

            xTravel = 0
          }else if(xTravel < 0){
            //println("test")
            for (x <- endX+1 to startX-1) {
              if(x == startX-1){
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path2)
              }else{
                path.next = new LinkedListNode[GridLocation](new GridLocation(x, y), path.next)
              }
            }

            if(xTravel == -1){
              path.next = path2
            }

            xTravel = 0
          }

          else{
            //println("test")
            path2.next = new LinkedListNode[GridLocation](new GridLocation(endX, endY), path2.next)
            endY +=1
          }

        }

    }

    path
  }


  def makeDecision(gameState: AIGameState, decisionTree: BinaryTreeNode[DecisionTreeValue]): AIAction = {
    val checkVal:Int = decisionTree.value.check(gameState)
    if (checkVal < 0){
      makeDecision(gameState,decisionTree.left)
    }else if (checkVal > 0){
      makeDecision(gameState,decisionTree.right)
    }else{
      decisionTree.value.action(gameState)
    }
  }


  // TODO: Replace this placeholder code with your own
  def closestPlayerAvoidWalls(gameState: AIGameState): PlayerLocation = {
    closestPlayer(gameState.playerLocations)
  }

  // TODO: Replace this placeholder code with your own
  def getPath(gameState: AIGameState): LinkedListNode[GridLocation] = {
    computePath(locatePlayer(this.id, gameState.playerLocations).asGridLocation(), closestPlayerAvoidWalls(gameState).asGridLocation())
  }




}

